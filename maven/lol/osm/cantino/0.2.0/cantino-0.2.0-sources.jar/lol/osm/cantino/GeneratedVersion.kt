// Generated from Cargo.toml by :cantino:generateVersionSource. Do not edit.
package lol.osm.cantino

internal const val GENERATED_VERSION: String = "0.2.0"
