// Generated from Cargo.toml by :cantino:generateVersionSource. Do not edit.
package io.github.mvexel.cantino

internal const val GENERATED_VERSION: String = "0.1.0"
